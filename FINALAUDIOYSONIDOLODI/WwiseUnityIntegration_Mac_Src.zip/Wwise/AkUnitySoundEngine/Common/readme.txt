The Unity script API binding is generated automatically from the Wwise SDK's native C++ interface.

Please read the documentation under the Documentation folder for more information.
